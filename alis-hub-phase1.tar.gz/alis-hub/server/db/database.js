const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');

const DB_DIR  = path.join(__dirname);
const DB_PATH = path.join(DB_DIR, 'alis-hub.sqlite');

let db;

function getDb() {
  if (!db) throw new Error('DB not initialized — call initDb() first');
  return db;
}

function initDb() {
  fs.mkdirSync(DB_DIR, { recursive: true });
  db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');

  db.exec(`
    CREATE TABLE IF NOT EXISTS jobs (
      id          TEXT PRIMARY KEY,
      type        TEXT NOT NULL,
      label       TEXT NOT NULL,
      status      TEXT NOT NULL DEFAULT 'queued',  -- queued | running | done | failed
      total       INTEGER DEFAULT 0,
      completed   INTEGER DEFAULT 0,
      failed      INTEGER DEFAULT 0,
      payload     TEXT,   -- JSON blob: companyUrl, communities[], etc.
      created_at  TEXT DEFAULT (datetime('now')),
      updated_at  TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS job_items (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id      TEXT NOT NULL REFERENCES jobs(id),
      name        TEXT NOT NULL,
      status      TEXT NOT NULL DEFAULT 'pending',  -- pending | running | success | failed
      error       TEXT,
      started_at  TEXT,
      finished_at TEXT
    );
  `);

  console.log('✅  DB initialized:', DB_PATH);
}

// ── Job helpers ─────────────────────────────────────────────────────

function createJob({ id, type, label, payload, communities }) {
  const db = getDb();
  db.prepare(`
    INSERT INTO jobs (id, type, label, status, total, payload)
    VALUES (?, ?, ?, 'queued', ?, ?)
  `).run(id, type, label, communities.length, JSON.stringify(payload));

  const insertItem = db.prepare(`
    INSERT INTO job_items (job_id, name) VALUES (?, ?)
  `);
  for (const c of communities) {
    insertItem.run(id, c.name);
  }
}

function getJob(id) {
  const db = getDb();
  const job   = db.prepare('SELECT * FROM jobs WHERE id = ?').get(id);
  if (!job) return null;
  job.payload = JSON.parse(job.payload || '{}');
  job.items   = db.prepare('SELECT * FROM job_items WHERE job_id = ? ORDER BY id').all(id);
  return job;
}

function listJobs() {
  const db = getDb();
  return db.prepare(`
    SELECT id, type, label, status, total, completed, failed, created_at, updated_at
    FROM jobs ORDER BY created_at DESC
  `).all();
}

function setJobStatus(id, status) {
  getDb().prepare(`
    UPDATE jobs SET status = ?, updated_at = datetime('now') WHERE id = ?
  `).run(status, id);
}

function updateJobCounts(id) {
  const db = getDb();
  const { completed } = db.prepare(
    `SELECT COUNT(*) AS completed FROM job_items WHERE job_id = ? AND status = 'success'`
  ).get(id);
  const { failed } = db.prepare(
    `SELECT COUNT(*) AS failed FROM job_items WHERE job_id = ? AND status = 'failed'`
  ).get(id);
  db.prepare(`
    UPDATE jobs SET completed = ?, failed = ?, updated_at = datetime('now') WHERE id = ?
  `).run(completed, failed, id);
}

function setItemStatus(jobId, name, status, error = null) {
  const db  = getDb();
  const now = new Date().toISOString();
  if (status === 'running') {
    db.prepare(`
      UPDATE job_items SET status = 'running', started_at = ? WHERE job_id = ? AND name = ?
    `).run(now, jobId, name);
  } else {
    db.prepare(`
      UPDATE job_items SET status = ?, error = ?, finished_at = ? WHERE job_id = ? AND name = ?
    `).run(status, error, now, jobId, name);
    updateJobCounts(jobId);
  }
}

module.exports = { initDb, getDb, createJob, getJob, listJobs, setJobStatus, setItemStatus };
