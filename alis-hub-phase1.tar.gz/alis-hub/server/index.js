require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');

const { initDb }   = require('./db/database');
const jobsRouter   = require('./api/jobs');
const streamRouter = require('./api/stream');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

// API routes
app.use('/api/jobs',   jobsRouter);
app.use('/api/stream', streamRouter);

// Health check
app.get('/api/health', (_, res) => res.json({ ok: true, ts: Date.now() }));

// Init DB then start
initDb();
app.listen(PORT, () => {
  console.log(`\n🚀  alis-hub server running at http://localhost:${PORT}\n`);
});
