// Add these to your server/index.js or routes file

// In-memory job control state (use Redis in production)
const jobControls = new Map();

// Initialize job control state
function initJobControl(jobId) {
  jobControls.set(jobId, {
    shouldPause: false,
    shouldCancel: false,
    isPaused: false
  });
}

// Check if job should pause (call this between items in your loop)
function shouldPauseJob(jobId) {
  const control = jobControls.get(jobId);
  return control?.shouldPause || false;
}

// Check if job should cancel
function shouldCancelJob(jobId) {
  const control = jobControls.get(jobId);
  return control?.shouldCancel || false;
}

// Wait while paused
async function checkPauseState(jobId, io) {
  const control = jobControls.get(jobId);
  if (!control) return;

  if (control.shouldPause && !control.isPaused) {
    control.isPaused = true;
    io.emit('job:paused', { jobId });
    
    // Wait until resume is called
    while (control.shouldPause && !control.shouldCancel) {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    control.isPaused = false;
    if (!control.shouldCancel) {
      io.emit('job:resumed', { jobId });
    }
  }
}

// Pause job endpoint
app.post('/api/jobs/:id/pause', async (req, res) => {
  const jobId = parseInt(req.params.id);
  
  try {
    // Update database
    await db.run(
      'UPDATE jobs SET status = ? WHERE id = ?',
      ['paused', jobId]
    );

    // Set control flag
    const control = jobControls.get(jobId) || { shouldPause: false, shouldCancel: false, isPaused: false };
    control.shouldPause = true;
    jobControls.set(jobId, control);

    res.json({ success: true, message: 'Job pause requested' });
  } catch (err) {
    console.error('Failed to pause job:', err);
    res.status(500).json({ error: 'Failed to pause job' });
  }
});

// Resume job endpoint
app.post('/api/jobs/:id/resume', async (req, res) => {
  const jobId = parseInt(req.params.id);
  
  try {
    // Update database
    await db.run(
      'UPDATE jobs SET status = ? WHERE id = ?',
      ['in_progress', jobId]
    );

    // Clear pause flag
    const control = jobControls.get(jobId) || { shouldPause: false, shouldCancel: false, isPaused: false };
    control.shouldPause = false;
    jobControls.set(jobId, control);

    res.json({ success: true, message: 'Job resumed' });
  } catch (err) {
    console.error('Failed to resume job:', err);
    res.status(500).json({ error: 'Failed to resume job' });
  }
});

// Cancel job endpoint
app.post('/api/jobs/:id/cancel', async (req, res) => {
  const jobId = parseInt(req.params.id);
  
  try {
    // Update database
    await db.run(
      'UPDATE jobs SET status = ?, completed_at = ? WHERE id = ?',
      ['cancelled', new Date().toISOString(), jobId]
    );

    // Set cancel flag
    const control = jobControls.get(jobId) || { shouldPause: false, shouldCancel: false, isPaused: false };
    control.shouldCancel = true;
    control.shouldPause = false; // Resume if paused so cancellation can proceed
    jobControls.set(jobId, control);

    io.emit('job:cancelled', { jobId });

    res.json({ success: true, message: 'Job cancelled' });
  } catch (err) {
    console.error('Failed to cancel job:', err);
    res.status(500).json({ error: 'Failed to cancel job' });
  }
});

// Updated job processor with pause/cancel support
async function processGLSyncJob(job, io) {
  const jobId = job.id;
  initJobControl(jobId);

  try {
    const items = JSON.parse(job.payload);
    
    io.emit('job:progress', { jobId, message: '══ Starting GL Account Sync Job ══' });

    for (const item of items) {
      // Check for cancellation
      if (shouldCancelJob(jobId)) {
        io.emit('job:progress', { jobId, message: '✗ Job cancelled by user' });
        throw new Error('Job cancelled by user');
      }

      // Check for pause
      await checkPauseState(jobId, io);

      // Emit starting message ONCE
      io.emit('job:progress', { 
        jobId, 
        message: `→ Starting: ${item.name}`,
        status: 'in_progress',
        itemName: item.name 
      });

      try {
        // Your existing GL sync logic here
        await syncGLRecords(item);
        
        io.emit('job:progress', { 
          jobId, 
          message: `✓ Done: ${item.name}`,
          status: 'success',
          itemName: item.name 
        });
      } catch (error) {
        io.emit('job:progress', { 
          jobId, 
          message: `✗ Failed: ${item.name} — ${error.message}`,
          status: 'failed',
          itemName: item.name 
        });
        // Continue with next item instead of failing entire job
      }
    }

    io.emit('job:progress', { jobId, message: '══ Job complete ══' });

    // Cleanup control state
    jobControls.delete(jobId);

  } catch (error) {
    console.error(`Job ${jobId} failed:`, error);
    throw error;
  }
}

// Export for use in your job processor
module.exports = {
  initJobControl,
  shouldPauseJob,
  shouldCancelJob,
  checkPauseState,
  processGLSyncJob
};
