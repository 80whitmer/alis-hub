import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';

export default function JobDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [logs, setLogs] = useState([]);
  const [isPaused, setIsPaused] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const logsEndRef = useRef(null);
  const socketRef = useRef(null);

  useEffect(() => {
    // Fetch initial job data
    fetch(`http://localhost:3000/api/jobs/${id}`)
      .then(res => res.json())
      .then(data => {
        setJob(data);
        if (data.logs) {
          setLogs(data.logs.split('\n').filter(Boolean));
        }
      })
      .catch(err => console.error('Failed to fetch job:', err));

    // Setup socket connection for live updates
    socketRef.current = io('http://localhost:3000');
    
    socketRef.current.on('job:progress', (data) => {
      if (data.jobId === parseInt(id)) {
        setLogs(prev => [...prev, data.message]);
      }
    });

    socketRef.current.on('job:status', (data) => {
      if (data.jobId === parseInt(id)) {
        setJob(prev => ({ ...prev, status: data.status }));
      }
    });

    socketRef.current.on('job:paused', (data) => {
      if (data.jobId === parseInt(id)) {
        setIsPaused(true);
        setJob(prev => ({ ...prev, status: 'paused' }));
      }
    });

    socketRef.current.on('job:resumed', (data) => {
      if (data.jobId === parseInt(id)) {
        setIsPaused(false);
        setJob(prev => ({ ...prev, status: 'in_progress' }));
      }
    });

    socketRef.current.on('job:cancelled', (data) => {
      if (data.jobId === parseInt(id)) {
        setJob(prev => ({ ...prev, status: 'cancelled' }));
        setIsCancelling(false);
      }
    });

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, [id]);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handlePauseResume = async () => {
    const action = isPaused ? 'resume' : 'pause';
    try {
      const response = await fetch(`http://localhost:3000/api/jobs/${id}/${action}`, {
        method: 'POST'
      });
      if (response.ok) {
        setIsPaused(!isPaused);
      }
    } catch (err) {
      console.error(`Failed to ${action} job:`, err);
    }
  };

  const handleCancel = async () => {
    if (!confirm('Are you sure you want to cancel this job? This action cannot be undone.')) {
      return;
    }
    
    setIsCancelling(true);
    try {
      const response = await fetch(`http://localhost:3000/api/jobs/${id}/cancel`, {
        method: 'POST'
      });
      if (response.ok) {
        // Status will be updated via socket event
      }
    } catch (err) {
      console.error('Failed to cancel job:', err);
      setIsCancelling(false);
    }
  };

  if (!job) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-gray-500">Loading job details...</div>
      </div>
    );
  }

  const statusColors = {
    pending: 'bg-gray-100 text-gray-700',
    in_progress: 'bg-blue-100 text-blue-700',
    paused: 'bg-yellow-100 text-yellow-700',
    completed: 'bg-green-100 text-green-700',
    failed: 'bg-red-100 text-red-700',
    cancelled: 'bg-orange-100 text-orange-700'
  };

  const canPause = job.status === 'in_progress' || job.status === 'paused';
  const canCancel = job.status === 'in_progress' || job.status === 'paused';

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={() => navigate('/')}
          className="text-blue-600 hover:text-blue-800 mb-4 flex items-center gap-2"
        >
          ← Back to Dashboard
        </button>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Job #{job.id}</h1>
            <p className="text-gray-600 mt-1">{job.type}</p>
          </div>
          <div className="flex items-center gap-3">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColors[job.status]}`}>
              {job.status.replace('_', ' ').toUpperCase()}
            </span>
            
            {/* Pause/Resume Button */}
            {canPause && (
              <button
                onClick={handlePauseResume}
                disabled={isCancelling}
                className={`px-4 py-2 rounded font-medium transition-colors ${
                  isPaused
                    ? 'bg-blue-600 hover:bg-blue-700 text-white'
                    : 'bg-yellow-600 hover:bg-yellow-700 text-white'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                {isPaused ? '▶ Resume' : '⏸ Pause'}
              </button>
            )}
            
            {/* Cancel Button */}
            {canCancel && (
              <button
                onClick={handleCancel}
                disabled={isCancelling}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isCancelling ? '⏳ Cancelling...' : '✕ Cancel'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Job Info */}
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">Job Information</h2>
        <dl className="grid grid-cols-2 gap-4">
          <div>
            <dt className="text-sm font-medium text-gray-500">Created</dt>
            <dd className="mt-1 text-sm text-gray-900">
              {new Date(job.created_at).toLocaleString()}
            </dd>
          </div>
          <div>
            <dt className="text-sm font-medium text-gray-500">Started</dt>
            <dd className="mt-1 text-sm text-gray-900">
              {job.started_at ? new Date(job.started_at).toLocaleString() : 'Not started'}
            </dd>
          </div>
          <div>
            <dt className="text-sm font-medium text-gray-500">Completed</dt>
            <dd className="mt-1 text-sm text-gray-900">
              {job.completed_at ? new Date(job.completed_at).toLocaleString() : 'Not completed'}
            </dd>
          </div>
          <div>
            <dt className="text-sm font-medium text-gray-500">Duration</dt>
            <dd className="mt-1 text-sm text-gray-900">
              {job.started_at && job.completed_at
                ? `${Math.round((new Date(job.completed_at) - new Date(job.started_at)) / 1000)}s`
                : job.started_at
                ? 'In progress...'
                : 'Not started'}
            </dd>
          </div>
        </dl>
      </div>

      {/* Live Log */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold">Live Log</h2>
            {(job.status === 'in_progress' || job.status === 'paused') && (
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${job.status === 'paused' ? 'bg-yellow-500' : 'bg-green-500 animate-pulse'}`}></div>
                <span className="text-sm text-gray-500">
                  {job.status === 'paused' ? 'Paused' : 'Live'}
                </span>
              </div>
            )}
          </div>
          <div className="text-sm text-gray-500">
            {logs.length} {logs.length === 1 ? 'entry' : 'entries'}
          </div>
        </div>
        
        <div className="p-4 bg-gray-900 text-gray-100 font-mono text-sm h-96 overflow-y-auto">
          {logs.length === 0 ? (
            <div className="text-gray-500">No logs yet...</div>
          ) : (
            <>
              {logs.map((log, idx) => (
                <div key={idx} className="py-1 whitespace-pre-wrap break-all">
                  {log}
                </div>
              ))}
              <div ref={logsEndRef} />
            </>
          )}
        </div>
      </div>

      {/* Error Message (if failed) */}
      {job.status === 'failed' && job.error && (
        <div className="mt-6 bg-red-50 border border-red-200 rounded-lg p-4">
          <h3 className="text-red-800 font-semibold mb-2">Error</h3>
          <pre className="text-red-700 text-sm whitespace-pre-wrap">{job.error}</pre>
        </div>
      )}

      {/* Pause Message */}
      {job.status === 'paused' && (
        <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center gap-2">
            <span className="text-yellow-800 font-semibold">⏸ Job Paused</span>
            <span className="text-yellow-700 text-sm">Click Resume to continue processing</span>
          </div>
        </div>
      )}

      {/* Cancel Message */}
      {job.status === 'cancelled' && (
        <div className="mt-6 bg-orange-50 border border-orange-200 rounded-lg p-4">
          <h3 className="text-orange-800 font-semibold mb-2">Job Cancelled</h3>
          <p className="text-orange-700 text-sm">This job was cancelled and did not complete.</p>
        </div>
      )}
    </div>
  );
}
